package dmpProject;

import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.IOException;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import org.jfree.ui.RefineryUtilities;

import ij.ImagePlus;
import ij.io.Opener;
import ij.process.ImageProcessor;


public class Main {
	
	static int py = 0; //peak
	
	static int Ybm = 0;
	static int Yb0 = 0;
	static int Yb1 = 0;
	static int diff = 0;
	
	static double peakFootConstantRel = 0.55;
	static double peakDiffMultiplicationConstant = 0.1;
	
	static Vector<Peak> peakList = new Vector<Peak>();

	public static void main(String[] args) throws IOException {
		
		// TODO Auto-generated method stub
		String imageFilePath = "C:\\Users\\User\\Desktop\\Image Processing\\dmpProject\\ma.jpg";
		
		Opener opener = new Opener();  		
		BufferedImage buff = ImageIO.read(new File(imageFilePath));
		ImagePlus imp = opener.openImage(imageFilePath);
		ImageProcessor ip = imp.getProcessor();
		run(ip);
		
		showImage(buff, "Band");
		
		for(int i = 0; i < peakList.size(); i++){
			Peak peak = peakList.elementAt(i);
			Yb0 = peak.getLeft();
			Yb1 = peak.getRight();
			diff = peak.getDiff();
			
			BufferedImage band = buff.getSubimage(0, Yb0, buff.getWidth(), diff);
			
			showImage(band, "Band " + i);

		}
	}

	public static void run(ImageProcessor ip){
		int M = ip.getWidth();
		int N = ip.getHeight();
		int[] horProj = new int[N];
		int[] verProj = new int[M];
		
		Peak peak = new Peak(0);

		//get all pixel values
		for(int v = 0; v < N; v++){
			for(int u = 0; u < M; u++){
				int p = ip.getPixel(u,v);
				horProj[v] += p;
				verProj[u] += p;
			}
		}
		
		//find Ybm (peak)		
		for(int i = 0; i < horProj.length; i++){
			if(horProj[i] > py){				
				py = horProj[i];
				Ybm = i;
				
			}
		}
		
		peak.setMax(Ybm);
		peak.setMaxValue(py);
		
		//find Yb0
		 int index=Ybm;
        for (int i=Ybm; i>=0; i--) {
            index = i;
            if (horProj[index] < peakFootConstantRel*horProj[Ybm] ) break;
        }
	      Yb0 =  Math.max(0,index);
	      System.out.println("Index: " + index);
	      
	      //find Yb1
	        for (int i=Ybm; i<horProj.length; i++) {
	            index = i;
	            if (horProj[index] < peakFootConstantRel*horProj[Ybm] ) break;
	        }
	       Yb1 = Math.min(horProj.length, index);
	       
	       diff = Yb1-Yb0;
	       
	       Yb0 -= peakDiffMultiplicationConstant * diff;   /*CONSTANT*/
           Yb1 += peakDiffMultiplicationConstant * diff;       
	      
           peak.setLeft(Yb0);
           peak.setRight(Yb1);
           peak.setDiff(diff);
           peakList.add(peak);
           
                      
			
		for(int i = 0; i< horProj.length; i++){
			System.out.println(horProj[i]);
		}
		
		System.out.println("Peak(py): " + py + " Index(Ybm): " + Ybm + " Yb0: " + Yb0 + " Yb1: " + Yb1);
				
		Graph g = new Graph("Horizontal Projection", horProj, "horizontal");
		g.pack( );        
		RefineryUtilities.centerFrameOnScreen(g);        
		g.setVisible( true ); 
		
//		Graph g2 = new Graph("Vertical Projection", verProj, "vertical");
//		g2.pack( );        
//		RefineryUtilities.centerFrameOnScreen(g2);        
//		g2.setVisible( true ); 
		
		//2nd peak
		py = 0; //reset peak value
		
		for(int i = 0; i < horProj.length; i++){
			if(allowedInterval(peakList, i)){
				if(horProj[i] >= py){
					py = horProj[i];
					Ybm = i; //second peak
				}
			}
				
		}
		
		Peak peak2 = new Peak(Ybm);
		peak2.setMaxValue(py);
				
		//find Yb0
		 	index=Ybm;
	        for (int i=Ybm; i>=0; i--) {
	            index = i;
	            if (horProj[index] < peakFootConstantRel*horProj[Ybm] ) break;
	        }
	      Yb0 =  Math.max(0,index);
	      
	      
	      //find Yb1
	        for (int i=Ybm; i<horProj.length; i++) {
	            index = i;
	            if (horProj[index] < peakFootConstantRel*horProj[Ybm] ) break;
	        }
	       Yb1 = Math.min(horProj.length, index);
	       
	       diff = Yb1-Yb0;
	       
	       Yb0 -= peakDiffMultiplicationConstant * diff;   /*CONSTANT*/
          
	       Yb1 += peakDiffMultiplicationConstant * diff;       
	       
	       System.out.println("Ybm 2: " + Ybm + " Yb0 2: " + Yb0 + " Yb1 2: " + Yb1);
	       
	       peak2.setLeft(Yb0);
	       peak2.setRight(Yb1);
	       peak2.setDiff(diff);
	       peakList.addElement(peak2);
	       
	       
	       //peak3
	       py = 0; //reset peak value
			
			for(int i = 0; i < horProj.length; i++){
				if(allowedInterval(peakList, i)){
					if(horProj[i] >= py){
						py = horProj[i];
						Ybm = i; //second peak
					}
				}
					
			}
			
			Peak peak3 = new Peak(Ybm);
			peak3.setMaxValue(py);
					
			//find Yb0
			 	index=Ybm;
		        for (int i=Ybm; i>=0; i--) {
		            index = i;
		            if (horProj[index] < peakFootConstantRel*horProj[Ybm] ) break;
		        }
		      Yb0 =  Math.max(0,index);
		      
		      
		      //find Yb1
		        for (int i=Ybm; i<horProj.length; i++) {
		            index = i;
		            if (horProj[index] < peakFootConstantRel*horProj[Ybm] ) break;
		        }
		       Yb1 = Math.min(horProj.length, index);
		       
		       diff = Yb1-Yb0;
		       
		       Yb0 -= peakDiffMultiplicationConstant * diff;   /*CONSTANT*/
	          
		       Yb1 += peakDiffMultiplicationConstant * diff;       
		       
		       System.out.println("Ybm 3: " + Ybm + " Yb0 3: " + Yb0 + " Yb1 3: " + Yb1);
		       
		       peak3.setLeft(Yb0);
		       peak3.setRight(Yb1);
		       peak3.setDiff(diff);
		       peakList.addElement(peak3);
	       
	}
	
	private static boolean allowedInterval(Vector<Peak> peaks, int i) {
		// TODO Auto-generated method stub
		 for (Peak peak : peaks)
	            if (peak.getLeft() <= i && i <= peak.getRight()) return false;
	        return true;
	}

	public static void showImage(BufferedImage img, String title) throws IOException{

		ImageIcon icon = new ImageIcon(img);
		
		JFrame frame = new JFrame();
		frame.setLayout(new FlowLayout());
		frame.setSize(200, 300);
		JLabel lbl = new JLabel();
		lbl.setIcon(icon);
		frame.setTitle(title);
		frame.add(lbl);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	
}
